var btn = document.querySelector("#btn");
btn.addEventListener("click", function() {
    var div = document.querySelector("#container");
    
  if(div.style.display === "none") {
        div.style.display = "block";
        document.querySelector("#container2").style.display = "none";
    } else {
      div.style.display = "none";
      document.querySelector("#container2").style.display = "block";
  }
    
});


var div2 = document.querySelector("#container2").style.display = "none";


